yum install git -y
